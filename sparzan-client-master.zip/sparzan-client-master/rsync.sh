rsync -rP -e 'ssh -p 8539' --delete-before /home/wlane/projects/sparzan-client/dist/spannotate/ tell@wulagi.damnserver.com:/var/www/html/
