# sparse-transcription-backend

The home for Sparse Transcription backend services: web api, db, and computational agents.